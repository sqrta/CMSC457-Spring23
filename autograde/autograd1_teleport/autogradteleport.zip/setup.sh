#!/usr/bin/env bash

apt-get install -y python3 python3-pip python3-dev

pip3 install numpy
pip3 install qiskit
pip3 install gradescope-utils