#!/usr/bin/env bash

apt-get install -y python3 python3-pip python3-dev
pip3 install gradescope-utils
pip3 install numpy==1.20.3
pip install qutip
